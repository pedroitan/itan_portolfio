import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { ArrowUpRight } from 'lucide-react';

const projects = [
  {
    title: 'Ethereal Dreams',
    category: 'Art Direction',
    image: 'https://images.unsplash.com/photo-1634986666676-ec8fd927c23d?auto=format&fit=crop&q=80',
    color: 'from-indigo-600 to-purple-600',
    size: 'large'
  },
  {
    title: 'Neon Nights',
    category: 'Brand Identity',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80',
    color: 'from-purple-600 to-pink-600',
    size: 'small'
  },
  {
    title: 'Mindscape',
    category: 'Digital Experience',
    image: 'https://images.unsplash.com/photo-1506792006437-256b665541e2?auto=format&fit=crop&q=80',
    color: 'from-pink-600 to-rose-600',
    size: 'medium'
  },
  {
    title: 'Quantum Leap',
    category: 'UI/UX Design',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80',
    color: 'from-rose-600 to-orange-600',
    size: 'small'
  },
  {
    title: 'Cyber Fusion',
    category: 'Motion Design',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&q=80',
    color: 'from-orange-600 to-amber-600',
    size: 'medium'
  },
  {
    title: 'Digital Renaissance',
    category: 'Creative Direction',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80',
    color: 'from-amber-600 to-yellow-600',
    size: 'large'
  }
];

// ... rest of the file remains the same ...