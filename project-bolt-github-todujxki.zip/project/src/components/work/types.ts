export interface Project {
  title: string;
  category: string;
  image: string;
  color: string;
  size: 'small' | 'medium' | 'large';
}