// Export the Work component as the default export
export { default } from './Work';

// Export other components and types for direct imports when needed
export * from './types';
export * from './ProjectCard';
export * from './projectsData';