import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const textVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: i * 0.1,
      duration: 0.8,
      ease: [0.215, 0.610, 0.355, 1.000],
    },
  }),
};

export default function Hero() {
  return (
    <div className="relative min-h-screen flex items-center overflow-hidden">
      <motion.div 
        className="absolute inset-0 bg-black"
        initial={{ scale: 1.2 }}
        animate={{ scale: 1 }}
        transition={{ duration: 1.5 }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/30 to-black/80" />
        <motion.div
          className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1600508774634-4e11d34730e2?auto=format&fit=crop&q=80')] bg-cover bg-center"
          initial={{ scale: 1.2, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.5 }}
          transition={{ duration: 1.5 }}
        />
      </motion.div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="max-w-4xl">
          <motion.div
            custom={1}
            initial="hidden"
            animate="visible"
            variants={textVariants}
            className="overflow-hidden"
          >
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 leading-tight">
              Hi, I'm Itan
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-500 to-pink-500">
                Creative Director
              </span>
              & Designer
            </h1>
          </motion.div>
          
          <motion.p
            custom={2}
            initial="hidden"
            animate="visible"
            variants={textVariants}
            className="text-xl md:text-2xl text-gray-300 mb-12 max-w-2xl"
          >
            Crafting immersive digital experiences and building brands that leave lasting impressions. 
            Let's create something extraordinary together.
          </motion.p>

          <motion.div
            custom={3}
            initial="hidden"
            animate="visible"
            variants={textVariants}
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-[2px] rounded-full"
            >
              <div className="bg-black rounded-full px-8 py-4 transition group-hover:bg-transparent">
                <span className="flex items-center space-x-2 text-white">
                  <span>View My Work</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </span>
              </div>
            </motion.button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}